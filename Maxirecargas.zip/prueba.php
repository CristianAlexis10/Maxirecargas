<?php

//Aca vamos a retornar un json que haria lopera

$data = array(1, 20, 13, 15, 12, 13);
echo json_encode($data);



 ?>
