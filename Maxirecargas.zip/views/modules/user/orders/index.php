<div class="order--fondo">
  <span class="menuorder"><i class="fa fa-bars" aria-hidden="true" id="menu"></i><i class="fa fa-bars" aria-hidden="true" id="menu-mobile"></i></span>
  <div class="user_fondo_order">
    <h1 class="user_title_order">para realizar tus <b>pedidos</b> debes iniciar sesión</h1>
    <a href="registrate"><button type="button" name="button">inicia sesión / regístrate </button></a>
    <a href="registrarse"><button type="button" name="button">regístrate</button></a>
    <a id="session_mobileOpen"><button type="button" name="button">inicia sesiòn</button></a>
  </div>
</div>
