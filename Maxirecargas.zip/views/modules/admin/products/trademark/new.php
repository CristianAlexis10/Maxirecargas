<div class="modules customers">
	<div class="title">
		<p>NUEVA MARCA</p>
	</div>
		 <form class="form Services" id="frmNewMar" enctype="multipart/form-data" >
		   <div class="form-group">
			   <label for="nombre" class="label">Nombre:</label>
			   <input type="text" name="dataNewMark" id="nombre" class=" input grande" required>
			 </div>
			 <div class="form-group">
			    <label for="des" class="label">Descripción:</label>
			    <textarea  id="desMar" class="textarea"></textarea>
			  </div>
  			<div class="form-group">
			     <button class="btn">Registrar</button>
			  </div>
		  </form>
	</div>
