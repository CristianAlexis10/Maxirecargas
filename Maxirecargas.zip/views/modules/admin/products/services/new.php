<div class="modules customers">
	<div class="title">
		<p>NUEVO SERVICIO</p>
	</div>
		<form class="frmServices" id="frmNewService" data-parsley-validate>
      <div class="form-group">
			    <label for="nombre" class="label">Nombre:</label>
			    <input type="text" name="dataNewService" id="nombre" class="input grande"required>
			</div>
			<div class="form-group">
			    <label for="des" class="des">Descripción:</label>
			    <textarea name="dataNewService" id="des" class="textarea"></textarea>
			</div>
			<div class="form-group">
			    <button class="btn">Registrar</button>
			</div>
		</form>

</div>
