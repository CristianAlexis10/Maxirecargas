<div class="wrap--menu" id="wrap--menu">
  <div class="menu--home">
    <img src="views/assets/image/iniciomenu.jpg">
    <div class="menu--title"><a href="maxirecargas">Inicio</a></div>
  </div>
  <div class="menu--order">
    <img src="views/assets/image/pedidosmenu.jpg">
    <div class="menu--title"><a href="pedidos">Pedidos</a></div>
  </div>
  <div class="menu--quotation">
    <img src="views/assets/image/cotizaciones.jpg">
    <div class="menu--title"><a href="cotizacion">Cotizaciones</a></div>
  </div>
  <div class="menu--product">
    <img src="views/assets/image/producto.jpg">
    <span id="close-menu">&times;</span>
    <div class="menu--title"><a href="productos">Productos</a></div>
  </div>
</div>

<div id="wrap--menu--mobile">
  <div id="close--mobile">
  &times;
  </div>
  <ul>
    <li><a href="maxirecargas">Inicio</a></li>
    <li><a href="pedidos">Pedidos</a></li>
    <li><a href="cotizacion">Cotizaciones</a></li>
    <li><a href="productos">Productos</a></li>
    <li><a href="miperfil">perfil</a></li>
    <li><a href="historial">historial</a></li>
    <li><a href="finalizar">cerrar sesión</a></li>
  </ul>
</div>
