
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="views/assets/js/copepr.js"></script>
<script type="text/javascript" src="views/assets/js/main-user.js"></script>
<script type="text/javascript" src="views/assets/js/orders.js"></script>
<script type="text/javascript" src="views/assets/js/menu.js"></script>
<script src="views/assets/lib/shortcut/shortcut.js"> </script>
<script type="text/javascript" src="views/assets/js/security.js"></script>

  </body>
</html>
