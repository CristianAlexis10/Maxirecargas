
                </article>
        	</div>
        </section>
 	 <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.99.0/js/materialize.min.js"></script>
     <script src="views/assets/js/croppie.js"></script>
     <script src="views/assets/js/cropp.js"></script>
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <script src="views/assets/js/table.js"></script>
   <script src="views/assets/lib/parsley/parsley.min.js"></script>
   <script src="views/assets/lib/parsley/es.js"></script>
   <script src="views/assets/js/main.js"></script>
   <script src="views/assets/js/config.js"></script>
   <script src="views/assets/js/settings.js"></script>
   <!-- <script src="views/assets/js/select.js"></script> -->
   <script src="views/assets/js/multiple-select.js"></script>
   <script src="views/assets/js/orders-admin.js"></script>
   <script src="views/assets/js/quotation-admin.js"></script>
   <script>
   if (document.getElementById('selectMul')) {
      $('#selectMul').multipleSelect({
            placeholder: "Selecciona los servicios"
        });
   }
     // $('#cuidad').zelect({ placeholder:'Selecciona una ciudad' })
    </script>
    <script src="views/assets/lib/shortcut/shortcut.js"> </script>
    <script type="text/javascript" src="views/assets/js/security.js"></script>
    </body>
</html>
